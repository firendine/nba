<div id="header">
    <a href="vengadores.php"><div class="option">Vengadores</div></a>
    <a href="liga.php"><div class="option">LJA</div></a>
    <a href="eternos.php"><div class="option">Sandman</div></a>
    <a href="login.php"><div class="option" id="login">Login</div></a>
    <a href="registrarse.php"><div class="option" id="login">Registrarse</div></a>
</div>