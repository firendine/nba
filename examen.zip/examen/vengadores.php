<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <title>Examen 1ª Evaluación</title>
    <link rel="stylesheet" type="text/css" media="screen" href="estilos.css" />
</head>
<body>
<?php
    include "menu.php";
?>  

<div id="content">
<a href="vengador.php?id=1">
<img src="imagenes/captain_america.png" class="imgAvg">
</a>
<a href="vengador.php?id=2">
<img src="imagenes/iron_man.png" class="imgAvg">
</a>
<a href="vengador.php?id=3">
<img src="imagenes/thor.png" class="imgAvg">
</a>
<a href="vengador.php?id=4">
<img src="imagenes/hulk.png" class="imgAvg">
</a>
<a href="vengador.php?id=5">
<img src="imagenes/black_widow.png" class="imgAvg">
</a>
<a href="vengador.php?id=6">
<img src="imagenes/hawkeye.png" class="imgAvg">
</a>

    
</div>
</body>
</html>