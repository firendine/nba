<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <title>Examen 1ª Evaluación</title>
    <link rel="stylesheet" type="text/css" media="screen" href="estilos.css" />
</head>
<body>
<?php
    include "menu.php";
?>  
<div id="content">
    <form action="./liga.php" method="POST">
        <select name="idSH">
        </select>
        <input type="submit" value="Ver">
    </form>
</div>
</body>
</html>